//
//  CollectionViewCell2.swift
//  AppYourBusiness
//
//  Created by Hui Guo on 16/8/15.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit

class CollectionViewCell2: UICollectionViewCell {

    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var blurView: UIView!
    @IBOutlet weak var postTitleLabel: UILabel!
    
}
