//
//  HomePageTableViewController.swift
//  AppYourBusiness
//
//  Created by Hui Guo on 16/8/14.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit

class HomePageTableViewController: UITableViewController, UICollectionViewDelegate, PostDelegate {
    let sections: NSArray = ["latest news", "good news"]
    var posts1: [Posts] = [Posts]()
    var selectedIndexPath: NSIndexPath?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
      if section < sections.count{
            return sections[section] as? String
        }
        
        return nil
 
    }

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return sections.count
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 1
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 && indexPath.section == 0 {
            let tableViewCell = tableView.dequeueReusableCellWithIdentifier("TableViewCell") as! TableViewCell
            
            tableViewCell.getCategories()
         //   tableViewCell.scrollToNextCell()
         //   tableViewCell.startTimer()
           tableViewCell.postDelegate = self
            
            return tableViewCell
            
        }
        else {
            let tableViewCell2 = tableView.dequeueReusableCellWithIdentifier("TableViewCell2") as! TableViewCell2
            
            tableViewCell2.getCategories()
            tableViewCell2.scrollToNextCell()
            tableViewCell2.startTimer()
            
            
            return tableViewCell2
        }
    }
    
/*
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        self.performSegueWithIdentifier("goToDetail", sender: TableViewCell())
        print("selected")
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let tableViewCell1 = sender as? TableViewCell,
        let postDetailPage = segue.destinationViewController as? DetailViewController{
            
            let selectedPosts = tableViewCell1.selectedPost1
            
            postDetailPage.selectedPost?.selectedPost1 = selectedPosts
        
    }

 
}
*/
    
    func selectedPost(post: Posts) {
        //You will get your post object here, do what you want now
        self.performSegueWithIdentifier("goToDetail", sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let tableViewCell1 = sender as? TableViewCell,
            let postDetailPage = segue.destinationViewController as? DetailViewController{
            
            let selectedPosts = tableViewCell1.selectedPost1
            
            postDetailPage.selectedPost?.selectedPost1 = selectedPosts
    }
}

}






