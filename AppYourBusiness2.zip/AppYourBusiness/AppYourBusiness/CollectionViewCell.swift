//
//  CollectionViewCell.swift
//  AppYourBusiness
//
//  Created by Hui Guo on 16/8/14.
//  Copyright © 2016年 Leo. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var blurView: UIView!
    @IBOutlet weak var postTitleLabel: UILabel!
    
   
}
